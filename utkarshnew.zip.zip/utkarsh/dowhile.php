<?php
$num = 1;
do {
echo " Execution number : $num <br>\n";
$num ++;
}
while ($num >200 && $num < 400);
?> 