<?php
echo "current php version : ". phpversion() ;
?>