<html>
<head>
<title> Writing PHP function with parameters </title>
</head>
<body>
<?php
function addfunction($num1 , $num2)
{
$sum = $num1 + $num2;
echo "sum of the two number is : $sum ";
}
addfunction(10,20);
?>
</body>
</html>