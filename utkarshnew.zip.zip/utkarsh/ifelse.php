<?php
if ($a = 10  > $b = 20)
{
echo "a is bigger than b";
} else
{
echo "a is NOT bigger than b";
}
?>