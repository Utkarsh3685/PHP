<?php
$handle = fopen ("note.txt" , "r");
var_dump ($handle);
?>