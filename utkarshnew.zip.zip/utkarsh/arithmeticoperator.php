<?php
$x = 10;
$y = 4;
echo " $x + $y =" . ($x + $y). " <br>" ;
 echo " $x - $y =" . ($x - $y). " <br>" ;
echo " $x * $y =" . ($x * $y). " <br>" ;
echo " $x / $y =" . ($x / $y). " <br>" ;
echo " $x % $y =" . ($x % $y). " <br>" ;
?>
