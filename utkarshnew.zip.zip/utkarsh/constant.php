<?php
define ("GREETING", "hello world !");
echo GREETING ;
?>