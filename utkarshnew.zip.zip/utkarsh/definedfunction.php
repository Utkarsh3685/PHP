<html>
<head>
<title> Writing PHP function </title>
</head>
<body>
<?php
echo "You are really a nice person, Have a nice time !";

writemessage ();
?>
</body>
</html>