<?php
function isArmstrong ($number) 
{
$num = 0;
$sum = 0;
$temp = $number;
while ($temp > 0)
{
$digit = $temp % 10;
$sum += $digit;
$temp = (int) ($temp / 10);
}
return $sum == $number;
}
$number = 70;
if (isArmstrong($number))
{
echo "$number is an Armstrong number. ";
}
else
{
echo "$number is not an Armstrong number.";
}
?> 