

<!DOCTYPE html>
<html>
<head>
    <title>Utkarsh Marks Report</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            padding: 20px;
            background-color: #f4f4f4;
        }
        table {
            width: 50%;
            margin: auto;
            border-collapse: collapse;
            background-color: #fff;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        .total {
            font-weight: bold;
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>

<h2 style="text-align:center;">Student Marks Report</h2>

<form method="post" style="text-align:center;">
    Enter marks for 5 subjects:<br><br>
    <input type="number" name="sub1" placeholder="Maths" required><br><br>
    <input type="number" name="sub2" placeholder="Physics" required><br><br>
    <input type="number" name="sub3" placeholder="Biology" required><br><br>
    <input type="number" name="sub4" placeholder="SSC" required><br><br>
    <input type="number" name="sub5" placeholder="History" required><br><br>
    <input type="submit" name="submit" value="Calculate">
</form>

<?php
if (isset($_POST['submit'])) {
    // Get input values
    $sub1 = $_POST['sub1'];
    $sub2 = $_POST['sub2'];
    $sub3 = $_POST['sub3'];
    $sub4 = $_POST['sub4'];
    $sub5 = $_POST['sub5'];

    // Calculate total and percentage
    $total = $sub1 + $sub2 + $sub3 + $sub4 + $sub5;
    $percentage = ($total / 500) * 100; // Assuming each subject is out of 100

    echo "<br><table>";
    echo "<tr><th>Subject</th><th>Marks</th></tr>";
    echo "<tr><td>Subject 1</td><td>$sub1</td></tr>";
    echo "<tr><td>Subject 2</td><td>$sub2</td></tr>";
    echo "<tr><td>Subject 3</td><td>$sub3</td></tr>";
    echo "<tr><td>Subject 4</td><td>$sub4</td></tr>";
    echo "<tr><td>Subject 5</td><td>$sub5</td></tr>";
    echo "<tr class='total'><td>Total Marks</td><td>$total / 500</td></tr>";
    echo "<tr class='total'><td>Percentage</td><td>" . number_format($percentage, 2) . "%</td></tr>";
    echo "</table>";
}
echo "<br>";
echo"This program is written by Utkarsh ";

?>

</body>
</html>