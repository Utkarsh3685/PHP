<?php
$favcolor = "red";
switch ($favcolor)
{
case "red":
echo "your favourite color is red! ";
break;

case "blue":
echo "your favourite color is blue! ";
break;

case "green":
echo "your favourite green is red! ";
break;
default:

echo "your favourite color is neither red, blue, nor green ! ";
}
?>

