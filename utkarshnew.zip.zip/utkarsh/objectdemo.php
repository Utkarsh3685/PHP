<? php
class greeting
{
public $ str = "Hello World !" ;
function show_greeting ()
{
return $ this -> str;
}
}
$message = new greetings;
var_dump ($message)
echo " This program is written by Utkarsh"
?>