<?php
$a = 10;
$b = 20;
if ($a < $b)
{
echo "out of $a and $b, $a is smaller";
}
?>