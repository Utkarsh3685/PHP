<?php
function findLargestNumber($arr) {
$largest = $arr[0];
foreach ($arr as $num)
{
if ($num > $largest)
{
$largest = $num;
}
}
return $largest;
}
$arr = array(1,2,3,4,5);
echo "The largest number in array is:" . findLargestNumber($arr);
?>