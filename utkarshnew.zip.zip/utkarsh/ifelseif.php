<?php
if ($a = 10 > $b = 15)
{
echo "a is bigger than b";
}
elseif ($a == $b)
{
echo "a is equal to b" ;
} 
else 
{
echo "a is smaller than b" ;
}
?>