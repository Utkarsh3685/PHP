<?php
$a = NULL;
var_dump($a);
echo "<br>";
$b = "Hello World !";
$b = NULL;
var_dump($b)
?>
