<?php
function test()
{
$greet = "Hello World !";
echo $greet;
}
test();
echo "<br>";
echo"This program is written by Utkarsh ";
?>