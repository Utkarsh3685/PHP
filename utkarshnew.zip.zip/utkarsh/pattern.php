<?php
$rows = 8;
for ($i = $rows; $i >= 1; $i --)
{
for ($j = 1; $j <= (2 * $i - 1); $j++)
{
echo "*";
}
echo "\n";
}
?>